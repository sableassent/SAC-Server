const categories = [
    "Automobile",
    "Baby Care",
    "Banquets",
    "Bills and Recharge",
    "Book Hotel",
    "Bus",
    "Caterers",
    "Chemists",
    "Doctor"
];
exports.categories = categories;